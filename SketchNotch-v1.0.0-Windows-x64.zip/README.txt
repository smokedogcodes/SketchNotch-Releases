SketchNotch v1.0.0 (Windows 11/10)
Hand-Drawn Dynamic Island Desktop Application

QUICK START:
1. Double-click `sketchnotch.exe` to launch.
2. The dynamic island will appear at the top-center camera notch of your display.
3. Make sure `WebView2Loader.dll` remains in the same folder as `sketchnotch.exe`.

HOTKEYS:
- Win + Space: Expand / Collapse Island drawer
- Ctrl + Alt + M: Global Mic Kill Switch
- Ctrl + Shift + S: Region Screenshot
- Win + Alt + C: Toggle Caffeine mode

LICENSE & ACTIVATION:
- Website & Simulator: https://sketchnotch.pages.dev
- Instant Free 7-Day Trial Key: SKNOTCH-TR-DEMO-0007
- Buy Permanent Lifetime License via WhatsApp: https://sketchnotch.pages.dev/#pricing
